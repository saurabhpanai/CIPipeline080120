INSERT INTO employees (first_name, last_name, department, email) VALUES ('Lorenz', 'Vanthillo', 'IT', 'lvthillo@mail.com');
